from utils import Indexer
from sentiment_data import read_sentiment_examples, SentimentExample


# build a dictionary for words in infile
def build_word_indexer(infile:str) -> Indexer:
    word_indexer = Indexer()
    word_indexer.add_and_get_index("UNK")  # 0 : unknown word
    word_indexer.add_and_get_index("PAD")  # 1 : use for padding !!!
    examples = read_sentiment_examples(infile)  # use words in train set
    for ex in examples:
        for word in ex.words:
            word_indexer.add_and_get_index(word)

    return word_indexer


# build a subword dictionary for things in infile
def build_subword_indexer(vocab) -> Indexer:
    subword_indexer = Indexer()
    subword_indexer.add_and_get_index("UNK")
    subword_indexer.add_and_get_index("PAD")  # 1 : use for padding !!!
    for word in vocab.keys():
        subword_indexer.add_and_get_index(word)

    return subword_indexer


# bpe method
def bpe(infile:str, merge_times):
    vocab = {}

    # initiate examples
    examples = read_sentiment_examples(infile)
    for ex in examples:
        for i, word in enumerate(ex.words):
            ex.words[i] = ' '.join(word[j:j+1] for j in range(len(word)))
            ex.words[i] = ex.words[i].split()
            # print(ex.words[i])

    # initiate vocab
    for ex in examples:
        for word in ex.words:
            for subword in word:
                if subword in vocab:
                    vocab[subword] += 1
                else:
                    vocab[subword] = 1

    print("merge times:")
    for x in range(merge_times):
        if x%100 == 0:
            print(x)

        # find most frequent pair
        pairs = {}
        for ex in examples:
            for word in ex.words:
                for i in range(len(word) - 1):
                    pair = word[i] + word[i+1]
                    if pair in pairs:
                        pairs[pair] += 1
                    else:
                        pairs[pair] = 1

        # renew vocab and examples
        most_frequent = max(pairs, key=pairs.get)
        max_count = pairs[most_frequent]
        vocab[most_frequent] = max_count
        for ex in examples:
            for word in ex.words:
                i = 0
                while i < len(word) - 1:
                    pair = word[i] + word[i+1]
                    if pair == most_frequent:
                        word[i] = most_frequent
                        del word[i+1]
                    else:
                        i += 1

    # renew examples
    for ex in examples:
        subwords = []
        for word in ex.words:
            for subword in word:
                subwords.append(subword)
        ex.words = subwords

    return examples, vocab


# turn sentences in examples into subwords form
def decode_test_set(examples, vocab):
    i = 0
    for ex in examples:
        ex.words = merge_words(ex.words, vocab)
        i += 1
        if i % 100 == 0:
            print(i)

    return examples


# turn a sentence in example into subwords
def merge_words(ex_words, vocab):
    merged = True
    vocab = dict(sorted(vocab.items(), key=lambda item: item[1], reverse=True))  # most frequent words first
    for index, key in enumerate(vocab.keys(), start=1):
        vocab[key] = index
    ex_words = [list(word) for word in ex_words]  # ['abcd', 'bcde', 'f'] -> [['a', 'b', 'c', 'd'], ['b', 'c', 'd', 'e'], ['f']]

    for i in range(len(ex_words)):
        while True:
            merged = False
            j = 0
            pos = len(vocab)
            while j < len(ex_words[i]) - 1:
                combined = ex_words[i][j] + ex_words[i][j + 1]
                if combined in vocab:
                    if vocab[combined] <= pos:
                        ex_words[i][j] = combined
                        del ex_words[i][j + 1]
                        merged = True
                        pos = vocab[combined]
                    else:
                        j += 1
                else:
                    j += 1
            if not merged:
                break

    # print(ex_words)
    ex_subwords = [subword for sublist in ex_words for subword in sublist]
    return ex_subwords


# print first x words in dictionary
def print_dic(dic:Indexer, x):
    print("\nAll indices in the Indexer:")
    if x > dic.__len__():  # x > dictionary size, print all
        x = -1

    # if x == -1, print all
    if x == -1:
        for obj, idx in dic.objs_to_ints.items():
            print(f"Object '{obj}' has Index {idx}")
        return

    # else, print first x words and indexes
    i = 0
    for obj, idx in dic.objs_to_ints.items():
        print(f"Object '{obj}' has Index {idx}")
        if i == x:
            break
        i += 1

    return


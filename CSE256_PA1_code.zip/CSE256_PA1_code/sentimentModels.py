import torch
from torch import nn
import torch.nn.functional as F


# DAN model for word embedding and subword embedding methods, + padding
class PaddingDAN(nn.Module):
    def __init__(self, vocab_size, embedding_dim, word_index):
        super(PaddingDAN, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.fc1 = nn.Linear(embedding_dim, 16)
        # self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(16, 2)
        self.dropout = nn.Dropout(0.4)  # Dropout layer
        self.word_index = word_index

    def forward(self, x):
        x = self.embedding(x)  # x has the shape (batch_size, seq_length)
        x = x.mean(dim=1)  # Average over the sequence length to obtain a fixed-dimensional output
        x = F.relu(self.fc1(x))
        # x = self.dropout(x)
        # x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return F.log_softmax(x, dim=1)


# DAN model, word embedding methods, using pretrained documents ( DAN MODEL TASK 1.1 )
class GloveDAN(nn.Module):
    def __init__(self, input_dim, hid_dim, output_dim, drop_rate):
        super(GloveDAN, self).__init__()
        self.fc1 = nn.Linear(input_dim, hid_dim)
        self.fc2 = nn.Linear(hid_dim, 16)
        self.fc3 = nn.Linear(16, output_dim)

        self.dropout = nn.Dropout(p=drop_rate)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.dropout(x)  # Dropout
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return F.log_softmax(x, dim=1)


# glove model using embedding.ini_layer
class GlovePaddingDAN(nn.Module):
    def __init__(self, word_embedding, hid_dim, drop_rate, frozen):
        super(GlovePaddingDAN, self).__init__()
        self.embedding = word_embedding.get_initialized_embedding_layer(frozen = frozen)
        self.hidden_layer = nn.Linear(word_embedding.get_embedding_length(), hid_dim)
        self.output_layer = nn.Linear(hid_dim, 2)
        self.dropout = nn.Dropout(p=drop_rate)

    def forward(self, x):
        x = self.embedding(x)
        x = x.mean(dim=1)
        x = self.dropout(x)
        x = F.relu(self.hidden_layer(x))
        x = self.output_layer(x)
        return F.log_softmax(x, dim=1)


# Two-layer fully connected neural network ( BOW MODEL )
class NN2BOW(nn.Module):
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, 2)
        self.log_softmax = nn.LogSoftmax(dim=1)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        x = self.log_softmax(x)
        return x


# Three-layer fully connected neural network ( BOW MODEL )
class NN3BOW(nn.Module):
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, 2)
        self.log_softmax = nn.LogSoftmax(dim=1)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return self.log_softmax(x)

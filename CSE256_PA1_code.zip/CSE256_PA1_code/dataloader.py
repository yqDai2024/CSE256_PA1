import torch
from sklearn.feature_extraction.text import CountVectorizer
from torch.utils.data import DataLoader
from torch.utils.data import Dataset
import time

from sentiment_data import read_sentiment_examples, read_word_embeddings
from build_indexer import build_word_indexer, build_subword_indexer, print_dic, bpe, decode_test_set
from sentimentModels import PaddingDAN, NN2BOW, NN3BOW, GlovePaddingDAN


class SentimentDatasetPaddingDAN(Dataset):
    def __init__(self, examples, word_index):
        self.examples = examples
        self.word_index = word_index
        self.word_indices_tensors = []

        for example in self.examples:
            self.word_indices = [self.word_index.index_of(word) for word in example.words]
            self.word_indices = [index if index != -1 else 0 for index in self.word_indices]  # turn -1 to 0
            word_indices_tensor = torch.tensor(self.word_indices, dtype=torch.long)

            # padding
            target_length = 50  # standard sentence length
            if len(word_indices_tensor) < target_length:
                padding = torch.full((target_length - len(word_indices_tensor),), 1, dtype=torch.long)
                word_indices_tensor = torch.cat((word_indices_tensor, padding))
            else:
                word_indices_tensor = word_indices_tensor[:target_length]

            self.word_indices_tensors.append(word_indices_tensor)

        self.labels = [ex.label for ex in self.examples]
        self.labels = torch.tensor(self.labels, dtype=torch.long)

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        return self.word_indices_tensors[idx], self.labels[idx]


# dataset for DAN model ( using glove embeddings )
class SentimentDatasetGLOVEDAN(Dataset):
    def __init__(self, infile, word_embeddings):
        # Read the sentiment examples from the input file
        self.examples = read_sentiment_examples(infile)
        self.word_embeddings = word_embeddings

        # Initialize a list to hold the average embeddings
        self.embeddings = []

        # Compute the average embedding for each example
        for ex in self.examples:
            # Get the embeddings for each word in the example
            word_vectors = [self.word_embeddings.get_embedding(word) for word in ex.words]

            # Calculate the average vector
            if word_vectors:  # Check if there are any vectors
                average_vector = sum(word_vectors) / len(word_vectors)
                average_vector = torch.FloatTensor(average_vector)  # Convert to tensor !!!!!!!
            else:
                average_vector = torch.zeros(self.word_embeddings.get_embedding_length())

            self.embeddings.append(average_vector)

        # Convert embeddings and labels to PyTorch tensors
        self.embeddings = torch.stack(self.embeddings)  # Shape: (num_examples, embedding_dim)
        self.labels = [ex.label for ex in self.examples]
        self.labels = torch.tensor(self.labels, dtype=torch.long)

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        # Return the feature vector and label for the given index
        return self.embeddings[idx], self.labels[idx]


# dataset for BOW models
class SentimentDatasetBOW(Dataset):
    def __init__(self, infile, vectorizer=None, train=True):
        # Read the sentiment examples from the input file
        self.examples = read_sentiment_examples(infile)

        # Extract sentences and labels from the examples
        self.sentences = [" ".join(ex.words) for ex in self.examples]  # list of string
        self.labels = [ex.label for ex in self.examples]  # list of int

        # Vectorize the sentences using CountVectorizer
        if train or vectorizer is None:
            self.vectorizer = CountVectorizer(max_features=512)
            self.embeddings = self.vectorizer.fit_transform(self.sentences).toarray()
        else:
            self.vectorizer = vectorizer
            self.embeddings = self.vectorizer.transform(self.sentences).toarray()

        # Convert embeddings and labels to PyTorch tensors
        self.embeddings = torch.tensor(self.embeddings, dtype=torch.float32)
        self.labels = torch.tensor(self.labels, dtype=torch.long)

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        # Return the feature vector and label for the given index
        return self.embeddings[idx], self.labels[idx]


# create dataloader for different models
def dataloader_generator(model_type):

    # assume we use 2 layers BOW models
    train_data = SentimentDatasetBOW("data/train.txt")
    dev_data = SentimentDatasetBOW("data/dev.txt")
    model = NN2BOW(input_size=512, hidden_size=100)
    start_time = time.time()

    # if not, change train_data and dev_Data to fix other type of models
    # 3 layer BOW model
    if model_type == 1:
        print("loading data for 3 layer BOW model")
        model = NN3BOW(input_size=512, hidden_size=100)

    # task 1.1 ( glove )
    elif model_type == 2:
        print("loading data for DAN models ( glove )")
        word_embeddings = read_word_embeddings('data/glove.6B.300d-relativized.txt')
        train_examples = read_sentiment_examples('data/train.txt')
        test_examples = read_sentiment_examples('data/dev.txt')

        train_data = SentimentDatasetPaddingDAN(train_examples, word_embeddings.word_indexer)
        dev_data = SentimentDatasetPaddingDAN(test_examples, word_embeddings.word_indexer)
        model = GlovePaddingDAN(word_embeddings, 16, 0.5, False)

    # task 1.2 + padding
    elif model_type == 3:
        print("loading data for DAN models")
        word_indexer = build_word_indexer('data/train.txt')  # get word indexer
        train_examples = read_sentiment_examples('data/train.txt')
        test_examples = read_sentiment_examples('data/dev.txt')

        train_data = SentimentDatasetPaddingDAN(train_examples, word_indexer)
        dev_data = SentimentDatasetPaddingDAN(test_examples, word_indexer)
        model = PaddingDAN(word_indexer.__len__(), 50, word_indexer)

    # task 2 + padding
    elif model_type == 4:
        print("loading data for SUBWORD DAN models")
        train_examples, vocab = bpe('data/train.txt', 1000)
        subword_indexer = build_subword_indexer(vocab)
        test_examples = read_sentiment_examples('data/dev.txt')
        print("bpe finished")
        print("vocab size = " + str(len(vocab)))
        test_examples = decode_test_set(test_examples, vocab)

        train_data = SentimentDatasetPaddingDAN(train_examples, subword_indexer)
        dev_data = SentimentDatasetPaddingDAN(test_examples, subword_indexer)
        model = PaddingDAN(subword_indexer.__len__(), 50, subword_indexer)


    # print data loading time
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"Data loaded in : {elapsed_time} seconds")

    # create train_loader, test_loader
    train_loader = DataLoader(train_data, batch_size=16, shuffle=True)
    test_loader = DataLoader(dev_data, batch_size=16, shuffle=False)

    return train_loader, test_loader, model
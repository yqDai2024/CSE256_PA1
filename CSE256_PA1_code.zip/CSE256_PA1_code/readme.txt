run the code:
python main.py --model DAN
python main.py --model SUBWORDDAN
(python main.py --model DAN: use DAN models. The first model uses glove, while the second one did not use retrained word embeddings; python main.py --model SUBWORDDAN: use subword DAN model)


python files:
sentimentModels.py: different models
dataloader.py: create datasets and dataloaders for different models
build_indexer.py: build word index or subword index, bpe method and decoder


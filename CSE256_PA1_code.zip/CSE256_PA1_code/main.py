# models.py
import argparse
import matplotlib.pyplot as plt

from dataloader import dataloader_generator
from sentimentModels import *

import torch
from sklearn.feature_extraction.text import CountVectorizer
from torch.utils.data import DataLoader
from torch.utils.data import Dataset
import time

from sentiment_data import read_sentiment_examples, read_word_embeddings
from build_indexer import build_word_indexer, build_subword_indexer, print_dic, bpe
from sentimentModels import PaddingDAN, NN2BOW, NN3BOW, GloveDAN
from dataloader import SentimentDatasetGLOVEDAN, SentimentDatasetPaddingDAN
from build_indexer import build_subword_indexer, decode_test_set, bpe


# Training function
def train_epoch(data_loader, model, loss_fn, optimizer):
    size = len(data_loader.dataset)
    num_batches = len(data_loader)
    model.train()
    train_loss, correct = 0, 0
    for batch, (X, y) in enumerate(data_loader):

        # Compute prediction error
        pred = model(X)
        loss = loss_fn(pred, y)
        train_loss += loss.item()
        correct += (pred.argmax(1) == y).type(torch.float).sum().item()  # 使用 pred > 0 进行二分类

        # Backpropagation
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    average_train_loss = train_loss / num_batches
    accuracy = correct / size
    return accuracy, average_train_loss


# Evaluation function
def eval_epoch(data_loader, model, loss_fn, optimizer):
    size = len(data_loader.dataset)
    num_batches = len(data_loader)
    model.eval()
    eval_loss = 0
    correct = 0
    with torch.no_grad():
        for batch, (X, y) in enumerate(data_loader):

            # Compute prediction error
            pred = model(X)
            loss = loss_fn(pred, y)
            eval_loss += loss.item()
            correct += (pred.argmax(1) == y).type(torch.float).sum().item()

    average_eval_loss = eval_loss / num_batches
    accuracy = correct / size
    return accuracy, average_eval_loss


# Experiment function to run training and evaluation for multiple epochs
def experiment(model, train_loader, test_loader):
    loss_fn = nn.NLLLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)

    all_train_accuracy = []
    all_test_accuracy = []
    for epoch in range(120):
        train_accuracy, train_loss = train_epoch(train_loader, model, loss_fn, optimizer)
        all_train_accuracy.append(train_accuracy)

        test_accuracy, test_loss = eval_epoch(test_loader, model, loss_fn, optimizer)
        all_test_accuracy.append(test_accuracy)

        if epoch % 10 == 9:
            print(f'Epoch #{epoch + 1}: train accuracy {train_accuracy:.3f}, dev accuracy {test_accuracy:.3f}')
    
    return all_train_accuracy, all_test_accuracy


def print_and_save_image(train_accuracy, test_accuracy, model_name, title):
    # Plot the testing accuracy
    plt.figure(figsize=(8, 6))
    plt.plot(train_accuracy, label=model_name + 'train accuracy')
    plt.plot(test_accuracy, label=model_name + 'test accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.title(title)
    plt.legend()
    plt.grid()

    # show the image
    # plt.show()

    # Save the testing accuracy figure
    saving_file = 'images/' + title + '.png'
    plt.savefig(saving_file)
    print(f"Dev accuracy plot saved as {saving_file}\n\n")


def main():

    # Set up argument parser
    parser = argparse.ArgumentParser(description='Run model training based on specified model type')
    parser.add_argument('--model', type=str, required=True, help='Model type to train (e.g., BOW)')

    # Parse the command-line arguments
    args = parser.parse_args()

    # Check if the model type is "BOW"
    if args.model == "BOW":
        print('bow models:')
        train_loader, test_loader, model = dataloader_generator(1)
        train_acc, test_acc = experiment(model, train_loader, test_loader)
        print_and_save_image(train_acc, test_acc, args.model, 'BOW')

    # Check if the model type is "DAN"
    elif args.model == "DAN":
        print('dan models:')
        train_loader, test_loader, model = dataloader_generator(2)
        print('DAN model using glove')
        train_acc_1, test_acc_1 = experiment(model, train_loader, test_loader)
        print_and_save_image(train_acc_1, test_acc_1, 'dan model(glove)', 'dan model accuracy')

        train_loader, test_loader, model = dataloader_generator(3)
        print('DAN model without pretrained embeddings')
        train_acc, dev_acc = experiment(model, train_loader, test_loader)
        print_and_save_image(train_acc, dev_acc, 'dan model', 'dan model(no pretrained embeddings) accuracy ')


    # check if the model is unpadding DAN
    elif args.model == "SUBWORDDAN":
        train_loader, test_loader, model = dataloader_generator(4)
        train_acc, dev_acc = experiment(model, train_loader, test_loader)
        print_and_save_image(train_acc, dev_acc, 'subword dan model', 'subword dan model accuracy_3')


if __name__ == "__main__":
    main()
